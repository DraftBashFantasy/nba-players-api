import requests

if __name__ == '__main__':
    requests.post("https://draftbashfantasy-nba-players-api.azurewebsites.net/api/v1/players")
